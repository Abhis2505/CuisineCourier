import mongoose from "mongoose";

export const  connectDB = async () =>{
    await mongoose.connect('mongoDB connection string/FOOD').then(()=>console.log("DB Connected"))
}

// add your mongoDB connection string above.