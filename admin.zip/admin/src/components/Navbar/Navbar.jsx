import React from 'react'
import './Navbar.css'
// import { assets } from '../../assets/assets'
import { assets } from '../../assets/assets'
import logo_1 from '../../assets/logo_1.png'

const Navbar = () => {
  return (
    <div className='navbar'>
      <img className='logo' src={logo_1} alt="" />
      <img className='profile' src={assets.profile_image} alt="" />
    </div>
  )
}

export default Navbar
